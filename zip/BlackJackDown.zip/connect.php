<?php
$host="127.0.0.1";
$us="root";
$pass="";
$db="blackjackdown";
$con=mysqli_connect($host,$us,$pass,$db);
?>
